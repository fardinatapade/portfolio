Installation Steps(Configuration)

1. Download and Unzip the file on your local system.
2. copy hostel folder Put this folder inside xampp/htdocs/ .
3. Database Configuration

Open PHPMyAdmin
Create a Database hostel.
Import database hostel.sql
Open Your browser put inside browser http://localhost/hostel/

****************************Login Details****************************

****************************Login Details for admin**************************** 
Usenrame: admin
Password: Test@1234
****************************Login Details for user****************************
Username: test@gmail.com
Password: Test@123
Or Register a new user